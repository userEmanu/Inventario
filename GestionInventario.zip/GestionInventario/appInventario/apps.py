from django.apps import AppConfig


class AppinventarioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appInventario'
